<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<title>Supplier Obat</title>
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body py-2 d-sm-flex align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Supplier Obat</h6>
            <div>
                <a 
                    href="#" 
                    data-toggle="modal"
                    data-target="#myModal"
                    type="submit" 
                    class="btn btn-sm btn-success">
                    <i class="fas fa-fw fa-plus fa-sm text-white-50"></i> Supplier</a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive ">
                <table
                    class="table"
                    id="tableSupplier"
                    width="100%"
                    cellspacing="0"
                    style="font-size:0.75rem;">
                    <thead class="table-bordered">
                        <tr>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Supplier Obat</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Alamat</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">No.hp</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Banyak Obat</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Action</th>
                        </tr>
                    </thead>

                    <tbody class="table-bordered">
                        <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $jumlah = DB::table('alternatif')->where('supplier',$d->id)->count();
                        ?>
                        <tr>
                            <td class="text-center"><?php echo e($d->nama); ?></td>
                            <td class="text-center"><?php echo e($d->alamat); ?></td>
                            <td class="text-center"><?php echo e($d->no_hp); ?></td>
                            <td class="text-center"><?php echo e($jumlah); ?></td>
                            <td class="text-center">
                                <a
                                    href="<?php echo e(url('supplier/update',[$d->id])); ?>">
                                    <i class="fas fa-edit fa-sm"></i></a>
                                <?php if($jumlah == 0): ?>
                                &nbsp;
                                <a
                                    href="<?php echo e(url('supplier/delete',[$d->id])); ?>">
                                    <i class="fas fa-trash fa-sm"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div
    class="modal fade"
    id="myModal"
    tabindex="-1"
    role="dialog"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Supplier</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form class="user" action="<?php echo e(url('supplier/add')); ?>" method="POST">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        Nama
                        <input
                            required="required"
                            type="text"
                            style="text-transform: capitalize;"
                            name="nama"
                            maxlength="20"
                            class="form-control form-control-user"
                            id="nama"
                            placeholder="Nama Farmasi"><br>
                        Alamat
                        <input
                            required="required"
                            type="text"
                            style="text-transform: capitalize;"
                            name="alamat"
                            maxlength="25"
                            class="form-control form-control-user"
                            id="alamat"
                            placeholder="Tangerang, Banten"><br>
                        No.hp
                        <input
                            required="required"
                            type="tel"
                            name="no_hp"
                            maxlength="13"
                            class="form-control form-control-user"
                            id="no_hp"
                            placeholder="0878xxxx">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-sm">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {
        $(
            '#tableSupplier'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
        });
    });
</script>
<script>
$('[type=tel]').on('change', function(e) {
  $(e.target).val($(e.target).val().replace(/[^\d\.]/g, ''))
})
$('[type=tel]').on('keypress', function(e) {
  keys = ['0','1','2','3','4','5','6','7','8','9','.']
  return keys.indexOf(event.key) > -1
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Amul\resources\views/supplier/index.blade.php ENDPATH**/ ?>