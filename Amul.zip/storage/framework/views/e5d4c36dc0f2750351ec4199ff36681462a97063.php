<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<title>Supplier Obat</title>
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body py-2 d-sm-flex align-items-center justify-content-center">
            <h6 class="m-0 font-weight-bold text-primary">Update Supplier Obat</h6>
        </div>
        <div class="card-body">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="p-4">
                        <form autocomplete="off" class="user" action="<?php echo e(url('supplier/store',[$dataset->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="autocomplete">
                                Nama Supplier
                                <input
                                    required
                                    name="nama"
                                    style="text-transform: uppercase;"
                                    type="text"
                                    class="form-control form-control-user"
                                    id="nama"
                                    value="<?php echo e($dataset->nama); ?>"
                                    placeholder="<?php echo e($dataset->nama); ?>"><br>
                                Alamat
                                <input
                                    required
                                    type="text"
                                    style="text-transform: capitalize;"
                                    name="alamat"
                                    maxlength="25"
                                    class="form-control form-control-user"
                                    id="alamat"
                                    value="<?php echo e($dataset->alamat); ?>"
                                    placeholder="<?php echo e($dataset->alamat); ?>"><br>
                                No.hp
                                <input
                                    required
                                    type="tel"
                                    name="no_hp"
                                    maxlength="13"
                                    class="form-control form-control-user"
                                    id="no_hp"
                                    value="<?php echo e($dataset->no_hp); ?>"
                                    placeholder="<?php echo e($dataset->no_hp); ?>">
                            </div><br>
                        <button type="submit" class="btn btn-primary btn-user btn-block">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$('[type=tel]').on('change', function(e) {
  $(e.target).val($(e.target).val().replace(/[^\d\.]/g, ''))
})
$('[type=tel]').on('keypress', function(e) {
  keys = ['0','1','2','3','4','5','6','7','8','9','.']
  return keys.indexOf(event.key) > -1
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Amul\resources\views/supplier/update.blade.php ENDPATH**/ ?>