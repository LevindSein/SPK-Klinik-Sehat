<?php
$role = Session::get('role');
?>

<?php
    $view = '';
    if ($role == 'master') {
        $view = 'layout.master';
    } 
    else if($role == 'admin'){
        $view = 'layout.admin';
    }
    else{
        $view = 'layout.dokter';
    }
?>


<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<title>Data Nilai</title>
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body py-2 d-sm-flex align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Data Nilai</h6>
        </div>
        <div class="card-body py-2 d-sm-flex align-items-center justify-content-start">
            <form class="user" action="<?php echo e(url('nilai')); ?>" method="GET">
                <div class="form-group" style="display:inline-block">
                    <select class="form-control btn-sm" name="kategori" id="kategori" required>
                        <option value=""><?php echo e($name); ?></option>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input style="display:none" name="id" value="1">
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Submit</button>
            </form>
        </div>
        <div class="card-body">
            <div class="table-responsive ">
                <table
                    class="table"
                    id="tableKriteria"
                    width="100%"
                    cellspacing="0"
                    style="font-size:0.75rem;">
                    <thead class="table-bordered">
                        <tr>
                            <th style="background-color:rgba(255, 212, 71, 0.2);" rowspan="2">Nama Obat</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);" rowspan="2">Satuan</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);" rowspan="2">Supplier</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);" colspan="5">Nilai Kriteria</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);" rowspan="2">Action</th>
                        </tr>
                        <tr>
                            <th style="background-color:rgba(50, 212, 71, 0.2);">Khasiat</th>
                            <th style="background-color:rgba(212, 50, 212, 0.2);">E.Samping</th>
                            <th style="background-color:rgba(50, 71, 212, 0.2);">Garansi</th>
                            <th style="background-color:rgba(212, 50, 212, 0.2);">Merk</th>
                            <th style="background-color:rgba(50, 212, 71, 0.2);">Harga</th>
                        </tr>
                    </thead>

                    <tbody class="table-bordered">
                        <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                        $supplier = DB::table('supplier')->where('id',$d->supplier)->select('nama')->first();
                        ?>
                        <tr>
                            <td class="text-center"><?php echo e($d->nama); ?></td>
                            <td class="text-center"><?php echo e($d->satuan); ?></td>
                            <td class="text-center"><?php echo e($supplier->nama); ?></td>
                            <td class="text-center"><?php echo e($d->khasiat); ?></td>
                            <td class="text-center"><?php echo e($d->efek); ?></td>
                            <td class="text-center"><?php echo e($d->garansi); ?></td>
                            <td class="text-center"><?php echo e($d->merk); ?></td>
                            <td class="text-center"><?php echo e($d->harga); ?></td>
                            <td class="text-center">
                                <a
                                    href="<?php echo e(url('nilai/update',[$d->id])); ?>">
                                    <i class="fas fa-edit fa-sm"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {
        $(
            '#tableKriteria'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "fixedColumns":   {
                "leftColumns": 3,
                "rightColumns": 1,
            },
            "scrollCollapse": true,
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($view, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Amul\resources\views/nilai/index.blade.php ENDPATH**/ ?>