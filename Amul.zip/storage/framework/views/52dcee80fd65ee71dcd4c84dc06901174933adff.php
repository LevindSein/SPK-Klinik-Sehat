<?php
function tgl_indo($tanggal){
	$bulan = array (
		1 =>   'Januari',
		'Februari',
		'Maret',
		'April',
		'Mei',
		'Juni',
		'Juli',
		'Agustus',
		'September',
		'Oktober',
		'November',
		'Desember'
	);
    $pecahkan = explode('-', $tanggal);
	return $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}
?>
<?php
$role = Session::get('role');
?>

<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<title>Cetak Laporan</title>
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body py-2 d-sm-flex align-items-center justify-content-between">
            <!--Print Form-->
            <h6 class="m-0 font-weight-bold text-primary">Data Laporan</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table
                    class="table display table-bordered"
                    id="tableLaporan"
                    width="100%"
                    cellspacing="0"
                    style="font-size:1rem;">
                    <thead>
                        <tr>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Bulan</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center" <?php $bulan = tgl_indo($d->bulan);?>><?php echo e($bulan); ?></td>
                            <td class="text-center">
                                <a
                                    href="<?php echo e(url('laporan/print',[$d->bulan])); ?>"
                                    target="_blank">
                                    <i class="fas fa-print"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {
        $(
            '#tableLaporan'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "bSortable": false,
            "ordering": false
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($role == 'master' ? 'layout.master' : 'layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Amul\resources\views/laporan/index.blade.php ENDPATH**/ ?>