<?php
$role = Session::get('role');
?>

<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<title>Data Alternatif</title>
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body py-2 d-sm-flex align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Data Alternatif</h6>
            <div>
                <a 
                    href="#" 
                    data-toggle="modal"
                    data-target="#myModal"
                    type="submit" 
                    class="btn btn-sm btn-success">
                    <i class="fas fa-fw fa-plus fa-sm text-white-50"></i> Alternatif</a>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive ">
                <table
                    class="table"
                    id="tableAlternatif"
                    width="100%"
                    cellspacing="0"
                    style="font-size:0.75rem;">
                    <thead class="table-bordered">
                        <tr>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Kode</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Nama</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Kategori</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Supplier</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Satuan</th>
                            <th style="background-color:rgba(255, 212, 71, 0.2);">Action</th>
                        </tr>
                    </thead>

                    <tbody class="table-bordered">
                        <?php $__currentLoopData = $dataset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($d->kode); ?></td>
                            <td class="text-center"><?php echo e($d->nama); ?></td>
                            <td class="text-center"><?php echo e($d->kat_nama); ?></td>
                            <td class="text-center"><?php echo e($d->sup_nama); ?></td>
                            <td class="text-center"><?php echo e($d->satuan); ?></td>
                            <td class="text-center">
                                <a
                                    href="<?php echo e(url('alternatif/update',[$d->id])); ?>">
                                    <i class="fas fa-edit fa-sm"></i></a>
                                &nbsp;
                                <a
                                    href="<?php echo e(url('alternatif/delete',[$d->id])); ?>">
                                    <i class="fas fa-trash fa-sm"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div
    class="modal fade"
    id="myModal"
    tabindex="-1"
    role="dialog"
    aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Alternatif</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form class="user" action="<?php echo e(url('alternatif/add')); ?>" method="POST">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        Nama
                        <input
                            required="required"
                            type="text"
                            style="text-transform: capitalize;"
                            name="alternatif"
                            class="form-control form-control-user"
                            id="alternatif"
                            placeholder="Nama Obat">
                    </div>
                    <div class="form-group">
                        Kategori
                        <select class="form-control" name="kategori" id="kategori" required>
                            <option value="">None</option>
                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        Supplier
                        <select class="form-control" name="supplier" id="supplier" required>
                            <option value="">None</option>
                            <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($s->id); ?>"><?php echo e($s->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        Satuan
                        <select class="form-control" name="satuan" id="satuan" required>
                            <option value="">None</option>
                            <option value="Box">Box</option>
                            <option value="Botol">Botol</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-sm">Tambah</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {
        $(
            '#tableAlternatif'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($role == 'master' ? 'layout.master' : 'layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Amul\resources\views/alternatif/index.blade.php ENDPATH**/ ?>