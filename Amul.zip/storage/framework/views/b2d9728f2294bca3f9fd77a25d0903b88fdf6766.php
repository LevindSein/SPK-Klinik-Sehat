<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<title>Update Penilaian Alternatif</title>
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body py-2 d-sm-flex align-items-center justify-content-center">
            <h6 class="m-0 font-weight-bold text-primary">Update Penelitian Alternatif</h6>
        </div>
        <div class="card-body">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="p-4">
                        <form autocomplete="off" class="user" action="<?php echo e(url('nilai/store',[$nilai->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="autocomplete">
                                Kode
                                <input
                                    readonly
                                    name="kode"
                                    type="text"
                                    class="form-control form-control-user"
                                    id="kode"
                                    value="<?php echo e($dataset->kode); ?>"
                                    placeholder="<?php echo e($dataset->kode); ?>"><br>
                                Nama Alternatif
                                <input
                                    readonly
                                    name="nama"
                                    style="text-transform: Capitalize;"
                                    type="text"
                                    class="form-control form-control-user"
                                    id="nama"
                                    value="<?php echo e($dataset->nama); ?>"
                                    placeholder="<?php echo e($dataset->nama); ?>"><br>
                                Khasiat
                                <input
                                    required
                                    name="khasiat"
                                    type="text"
                                    class="form-control form-control-user"
                                    id="khasiat"
                                    value="<?php echo e($dataset->khasiat); ?>"
                                    placeholder="<?php echo e($dataset->khasiat); ?>"><br>
                                Efek Samping
                                <input
                                    name="efek"
                                    type="text"
                                    class="form-control form-control-user"
                                    id="efek"
                                    value="<?php echo e($dataset->efek); ?>"
                                    placeholder="<?php echo e($dataset->efek); ?>"><br>
                                Garansi (hari)
                                <input
                                    name="garansi"
                                    min="0"
                                    type="number"
                                    class="form-control form-control-user"
                                    id="garansi"
                                    value="<?php echo e($dataset->garansi); ?>"
                                    placeholder="<?php echo e($dataset->garansi); ?>"><br>
                                Merk
                                <input
                                    name="merk"
                                    type="text"
                                    class="form-control form-control-user"
                                    id="merk"
                                    value="<?php echo e($dataset->merk); ?>"
                                    placeholder="<?php echo e($dataset->merk); ?>"><br>
                                Harga (Rp)
                                <input
                                    required
                                    name="harga"
                                    min="0"
                                    type="number"
                                    class="form-control form-control-user"
                                    id="harga"
                                    value="<?php echo e($dataset->harga); ?>"
                                    placeholder="<?php echo e($dataset->harga); ?>">
                            </div><br>
                        <button type="submit" class="btn btn-primary btn-user btn-block">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
$('[type=tel]').on('change', function(e) {
  $(e.target).val($(e.target).val().replace(/[^\d\.]/g, ''))
})
$('[type=tel]').on('keypress', function(e) {
  keys = ['0','1','2','3','4','5','6','7','8','9','.']
  return keys.indexOf(event.key) > -1
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Amul\resources\views/nilai/update.blade.php ENDPATH**/ ?>