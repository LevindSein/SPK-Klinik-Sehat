<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<title>Update Alternatif</title>
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body py-2 d-sm-flex align-items-center justify-content-center">
            <h6 class="m-0 font-weight-bold text-primary">Update Alternatif</h6>
        </div>
        <div class="card-body">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="p-4">
                        <form autocomplete="off" class="user" action="<?php echo e(url('alternatif/store',[$dataset->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="autocomplete">
                                Kode
                                <input
                                    readonly
                                    name="kode"
                                    type="text"
                                    class="form-control form-control-user"
                                    id="kode"
                                    value="<?php echo e($dataset->kode); ?>"
                                    placeholder="<?php echo e($dataset->kode); ?>"><br>
                                Nama Alternatif
                                <input
                                    required
                                    name="nama"
                                    style="text-transform: Capitalize;"
                                    type="text"
                                    class="form-control form-control-user"
                                    id="nama"
                                    value="<?php echo e($dataset->nama); ?>"
                                    placeholder="<?php echo e($dataset->nama); ?>"><br>
                                Kategori
                                <select class="form-control" name="kategori" id="kategori" required>
                                    <option value="<?php echo e($dataset->kategori); ?>"><?php $kat = DB::table('kategori')->where('id',$dataset->kategori)->first()?> <?php echo e($kat->nama); ?></option>
                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select><br>
                                Supplier
                                <select class="form-control" name="supplier" id="supplier" required>
                                    <option value="<?php echo e($dataset->supplier); ?>"><?php $sup = DB::table('supplier')->where('id',$dataset->supplier)->first()?> <?php echo e($sup->nama); ?></option>
                                    <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($s->id); ?>"><?php echo e($s->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select><br>
                                Satuan
                                <select class="form-control" name="satuan" id="satuan" required>
                                    <option value="<?php echo e($dataset->satuan); ?>"><?php echo e($dataset->satuan); ?></option>
                                    <option value="Box">Box</option>
                                    <option value="Botol">Botol</option>
                                </select><br>
                            </div><br>
                        <button type="submit" class="btn btn-primary btn-user btn-block">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Amul\resources\views/alternatif/update.blade.php ENDPATH**/ ?>