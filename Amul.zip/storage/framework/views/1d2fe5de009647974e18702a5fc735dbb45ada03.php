<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-block" id="success-alert">
        <strong>Success! </strong><?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-block" id="error-alert">
        <strong>Oops! </strong><?php echo e($message); ?> 
</div>
<?php endif; ?>


<?php if($message = Session::get('warning')): ?>
<div class="alert alert-warning alert-block" id="warning-alert">
	<strong>Warning! </strong> <?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($message = Session::get('info')): ?>
<div class="alert alert-info alert-block" id="warning-alert">	
	<strong>Info! </strong><?php echo e($message); ?>

</div>
<?php endif; ?>


<?php if($errors->any()): ?>
<div class="alert alert-danger">	
	Please check the form below for errors
</div>
<?php endif; ?>
<?php /**PATH D:\Amul\resources\views/flash-message.blade.php ENDPATH**/ ?>