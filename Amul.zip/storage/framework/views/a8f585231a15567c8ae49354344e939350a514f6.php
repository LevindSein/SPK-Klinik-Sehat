<?php
$role = Session::get('role');
?>

<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<title>Keputusan Metode Electre</title>
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body py-2 d-sm-flex align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Temukan Hasil Keputusan</h6>
        </div>
        <div class="card-body py-2 d-sm-flex align-items-center justify-content-start">
            <form class="user" action="<?php echo e(url('electre')); ?>" method="GET">
                <div class="form-group" style="display:inline-block">
                    <select class="form-control btn-sm" name="kategori" id="kategori" required>
                        <option value=""><?php echo e($data); ?></option>
                        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input style="display:none" name="id" value="1">
                </div>
                <button type="submit" class="btn btn-primary btn-sm">Temukan</button>
            </form>
        </div>
        <?php if($value == 1): ?>
        <div class="card-body">
        <div class="form-group">
                <label for="sel1">Keputusan berdasarkan Metode Electre :</label>
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#home">Hasil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#menu1">Rincian</a>
                    </li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                    <!--HASIL-->
                    <div id="home" class="container tab-pane active">
                        <br>
                        Berikut adalah Agregat untuk Obat Kategori <b><u><?php echo e($data); ?></u></b> :<br><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="tableHasil"
                                width="70%"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th style="background-color:rgba(255, 212, 71, 0.2);">Poin</th>
                                        <th style="background-color:rgba(255, 212, 71, 0.2);">Nama Obat</th>
                                        <th style="background-color:rgba(255, 212, 71, 0.2);">Supplier</th>
                                        <th style="background-color:rgba(255, 212, 71, 0.2);">Ajukan</th>
                                    </tr>
                                </thead>

                                <tbody class="table-bordered">
                                    <?php for($i=0; $i < count($id); $i++): ?>
                                    <?php
                                    $obat = DB::table('alternatif')
                                    ->leftJoin('supplier','alternatif.supplier','=','supplier.id')
                                    ->where('alternatif.id',$id[$i])
                                    ->select('alternatif.id as obatId','alternatif.nama as alt','supplier.nama as sup')
                                    ->first();
                                    ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($agregat[$i]); ?></td>
                                        <td class="text-center"><?php echo e($obat->alt); ?></td>
                                        <td class="text-center"><?php echo e($obat->sup); ?></td>
                                        <td class="text-center">
                                            <a
                                                href="<?php echo e(url('laporan/store',[$obat->obatId])); ?>" target="_blank"><i class="fas fa-paper-plane"></i></a>
                                        </td>
                                    </tr>
                                    <?php endfor; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!--END HASIL-->
                    <!--RINCIAN-->
                    <div id="menu1" class="container tab-pane fade">
                        <br>
                        Berikut adalah Rincian Metode Electre untuk Obat Kategori <b><u><?php echo e($data); ?></u></b> :<br><br>
                        <h6 class="m-0 font-weight-bold text-primary">Data Nilai Awal</h6><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="nilaiAwal"
                                width="100%"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);"  rowspan="2">No.</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);"  rowspan="2">Nama Obat</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);"  colspan="5">Kriteria</th>
                                    </tr>
                                    <tr>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" >Khasiat</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" >E.Samping</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" >Garansi</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" >Merk</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" >Harga</th>
                                    </tr>
                                </thead>

                                <tbody class="table-bordered"><?php $no = 1;?>
                                <?php $__currentLoopData = $nilaiAwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($no); ?></td>
                                        <td class="text-center"><?php echo e($nilai->nama); ?></td>
                                        <td class="text-center"><?php echo e($nilai->khasiat); ?></td>
                                        <td class="text-center"><?php echo e($nilai->efek); ?></td>
                                        <td class="text-center"><?php echo e($nilai->garansi); ?></td>
                                        <td class="text-center"><?php echo e($nilai->merk); ?></td>
                                        <td class="text-center"><?php echo e($nilai->harga); ?></td>
                                    </tr>
                                    <?php $no++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div><br>

                        <h6 class="m-0 font-weight-bold text-primary">Matriks Normalisasi</h6><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="matriksNormalisasi"
                                width="100%"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" rowspan="2">No.</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" rowspan="2">Nama Obat</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" colspan="5">Kriteria</th>
                                    </tr>
                                    <tr>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);">Khasiat</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);">E.Samping</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);">Garansi</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);">Merk</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);">Harga</th>
                                    </tr>
                                </thead>

                                <tbody class="table-bordered"><?php $no = 1;?>
                                <?php for($i=0 ; $i < count($matriksNormalisasi) ; $i++): ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($no); ?></td>
                                        <td class="text-center"><?php echo e($matriksNormalisasi[$i][5]); ?></td>
                                        <td class="text-center"><?php echo e(number_format((float)$matriksNormalisasi[$i][0], 3, '.', '')); ?></td>
                                        <td class="text-center"><?php echo e(number_format((float)$matriksNormalisasi[$i][1], 3, '.', '')); ?></td>
                                        <td class="text-center"><?php echo e(number_format((float)$matriksNormalisasi[$i][2], 3, '.', '')); ?></td>
                                        <td class="text-center"><?php echo e(number_format((float)$matriksNormalisasi[$i][3], 3, '.', '')); ?></td>
                                        <td class="text-center"><?php echo e(number_format((float)$matriksNormalisasi[$i][4], 3, '.', '')); ?></td>
                                    </tr>
                                    <?php $no++; ?>
                                <?php endfor; ?>
                                </tbody>
                            </table>
                        </div><br>

                        <h6 class="m-0 font-weight-bold text-primary">Matriks Normalisasi Terbobot</h6><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="bobotNormalisasi"
                                width="100%"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);"  rowspan="2">No.</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);"  rowspan="2">Nama Obat</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);"  colspan="5">Kriteria</th>
                                    </tr>
                                    <tr>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" >Khasiat</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" >E.Samping</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" >Garansi</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" >Merk</th>
                                        <th style="background-color:rgba(0, 212, 71, 0.2);" >Harga</th>
                                    </tr>
                                </thead>

                                <tbody class="table-bordered"><?php $no = 1;?>
                                <?php for($i=0 ; $i < count($bobotNormalisasi) ; $i++): ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($no); ?></td>
                                        <td class="text-center"><?php echo e($bobotNormalisasi[$i][5]); ?></td>
                                        <td class="text-center"><?php echo e(number_format((float)$bobotNormalisasi[$i][0], 3, '.', '')); ?></td>
                                        <td class="text-center"><?php echo e(number_format((float)$bobotNormalisasi[$i][1], 3, '.', '')); ?></td>
                                        <td class="text-center"><?php echo e(number_format((float)$bobotNormalisasi[$i][2], 3, '.', '')); ?></td>
                                        <td class="text-center"><?php echo e(number_format((float)$bobotNormalisasi[$i][3], 3, '.', '')); ?></td>
                                        <td class="text-center"><?php echo e(number_format((float)$bobotNormalisasi[$i][4], 3, '.', '')); ?></td>
                                    </tr>
                                    <?php $no++; ?>
                                <?php endfor; ?>
                                </tbody>
                            </table>
                        </div><br>

                        <h6 class="m-0 font-weight-bold text-primary">Himpunan Index Concordance & Discordance</h6><br>
                        <h8 class="m-0 font-weight-bold text-primary">Index Concordance</h8><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="cIndex"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th style="background-color:rgba(255, 0, 255, 0.2);">&nbsp;</th>
                                        <?php for($i=0; $i < count($cIndex); $i++): ?>
                                        <th style="background-color:rgba(255, 0, 255, 0.2);">Obat <?php echo e($i+1); ?></th>
                                        <?php endfor; ?>
                                    </tr>
                                </thead>
                                <tbody class="table-bordered"><?php $no = 1;?>
                                    <?php $__currentLoopData = $cIndex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center" style="background-color:rgba(255, 0, 255, 0.2);"><b>Obat <?php echo e($no); ?></b></td>
                                        <?php for($i=0; $i < count($c); $i++): ?>
                                        <td class="text-center">
                                        <?php if($c[$i] == NULL): ?>
                                        &mdash;
                                        <?php else: ?>
                                        { <?php echo e($c[$i]); ?> }
                                        <?php endif; ?>
                                        </td>
                                        <?php endfor; ?>
                                    </tr>
                                    <?php $no++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <h8 class="m-0 font-weight-bold text-primary">Index Discordance</h8><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="dIndex"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th style="background-color:rgba(255, 255, 71, 0.2);">&nbsp;</th>
                                        <?php for($i=0; $i < count($dIndex); $i++): ?>
                                        <th style="background-color:rgba(255, 255, 71, 0.2);">Obat <?php echo e($i+1); ?></th>
                                        <?php endfor; ?>
                                    </tr>
                                </thead>
                                <tbody class="table-bordered"><?php $no = 1;?>
                                    <?php $__currentLoopData = $dIndex; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center" style="background-color:rgba(255, 255, 71, 0.2);"><b>Obat <?php echo e($no); ?></b></td>
                                        <?php for($i=0; $i < count($d); $i++): ?>
                                        <td class="text-center">
                                        <?php if($d[$i] == NULL): ?>
                                        &mdash;
                                        <?php else: ?>
                                        { <?php echo e($d[$i]); ?> }
                                        <?php endif; ?>
                                        </td>
                                        <?php endfor; ?>
                                    </tr>
                                    <?php $no++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div><br>

                        <h6 class="m-0 font-weight-bold text-primary">Matriks Concordance</h6><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="cMatriks"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th style="background-color:rgba(255, 0, 255, 0.2);">&nbsp;</th>
                                        <?php for($i=0; $i < count($cMatriks); $i++): ?>
                                        <th style="background-color:rgba(255, 0, 255, 0.2);">Obat <?php echo e($i+1); ?></th>
                                        <?php endfor; ?>
                                    </tr>
                                </thead>
                                <tbody class="table-bordered"><?php $no = 1;?>
                                    <?php for($i=0; $i < count($cMatriks); $i++): ?>
                                    <tr>
                                        <td class="text-center" style="background-color:rgba(255, 0, 255, 0.2);"><b>Obat <?php echo e($no); ?></b></td>
                                        <?php for($j=0; $j < count($cMatriks); $j++): ?>
                                        <td class="text-center">
                                        <?php if($i == $j): ?>
                                        &mdash;
                                        <?php else: ?>
                                        <?php echo e($cMatriks[$i][$j]); ?>

                                        <?php endif; ?>
                                        </td>
                                        <?php endfor; ?>
                                    </tr>
                                    <?php $no++; ?>
                                    <?php endfor; ?>
                                </tbody>
                            </table>
                        </div><br>

                        <h6 class="m-0 font-weight-bold text-primary">Matriks Discordance</h6><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="dMatriks"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th style="background-color:rgba(255, 255, 71, 0.2);">&nbsp;</th>
                                        <?php for($i=0; $i < count($dMatriks); $i++): ?>
                                        <th style="background-color:rgba(255, 255, 71, 0.2);">Obat <?php echo e($i+1); ?></th>
                                        <?php endfor; ?>
                                    </tr>
                                </thead>
                                <tbody class="table-bordered"><?php $no = 1;?>
                                    <?php for($i=0; $i < count($dMatriks); $i++): ?>
                                    <tr>
                                        <td class="text-center" style="background-color:rgba(255, 255, 71, 0.2);"><b>Obat <?php echo e($no); ?></b></td>
                                        <?php for($j=0; $j < count($dMatriks); $j++): ?>
                                        <td class="text-center">
                                        <?php if($i == $j): ?>
                                        &mdash;
                                        <?php else: ?>
                                        <?php echo e($dMatriks[$i][$j]); ?>

                                        <?php endif; ?>
                                        </td>
                                        <?php endfor; ?>
                                    </tr>
                                    <?php $no++; ?>
                                    <?php endfor; ?>
                                </tbody>
                            </table>
                        </div><br>

                        <h6 class="m-0 font-weight-bold text-primary">Matriks Dominan Concordance</h6><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="cThreshold"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th style="background-color:rgba(255, 0, 255, 0.2);">&nbsp;</th>
                                        <?php for($i=0; $i < count($cThreshold); $i++): ?>
                                        <th style="background-color:rgba(255, 0, 255, 0.2);">Obat <?php echo e($i+1); ?></th>
                                        <?php endfor; ?>
                                    </tr>
                                </thead>
                                <tbody class="table-bordered"><?php $no = 1;?>
                                    <?php for($i=0; $i < count($cThreshold); $i++): ?>
                                    <tr>
                                        <td class="text-center" style="background-color:rgba(255, 0, 255, 0.2);"><b>Obat <?php echo e($no); ?></b></td>
                                        <?php for($j=0; $j < count($cThreshold); $j++): ?>
                                        <td class="text-center">
                                        <?php if($i == $j): ?>
                                        &mdash;
                                        <?php else: ?>
                                        <?php echo e($cThreshold[$i][$j]); ?>

                                        <?php endif; ?>
                                        </td>
                                        <?php endfor; ?>
                                    </tr>
                                    <?php $no++; ?>
                                    <?php endfor; ?>
                                </tbody>
                            </table>
                        </div><br>

                        <h6 class="m-0 font-weight-bold text-primary">Matriks Dominan Discordance</h6><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="dThreshold"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th style="background-color:rgba(255, 255, 71, 0.2);">&nbsp;</th>
                                        <?php for($i=0; $i < count($dThreshold); $i++): ?>
                                        <th style="background-color:rgba(255, 255, 71, 0.2);">Obat <?php echo e($i+1); ?></th>
                                        <?php endfor; ?>
                                    </tr>
                                </thead>
                                <tbody class="table-bordered"><?php $no = 1;?>
                                    <?php for($i=0; $i < count($dThreshold); $i++): ?>
                                    <tr>
                                        <td class="text-center" style="background-color:rgba(255, 255, 71, 0.2);"><b>Obat <?php echo e($no); ?></b></td>
                                        <?php for($j=0; $j < count($dThreshold); $j++): ?>
                                        <td class="text-center">
                                        <?php if($i == $j): ?>
                                        &mdash;
                                        <?php else: ?>
                                        <?php echo e($dThreshold[$i][$j]); ?>

                                        <?php endif; ?>
                                        </td>
                                        <?php endfor; ?>
                                    </tr>
                                    <?php $no++; ?>
                                    <?php endfor; ?>
                                </tbody>
                            </table>
                        </div><br>

                        <h6 class="m-0 font-weight-bold text-primary">Dominan Conclusion</h6><br>
                        <div class="table-responsive ">
                            <table
                                class="table"
                                id="dominasi"
                                cellspacing="0"
                                style="font-size:0.75rem;">
                                <thead class="table-bordered">
                                    <tr>
                                        <th>&nbsp;</th>
                                        <?php for($i=0; $i < count($dominasi); $i++): ?>
                                        <th>Obat <?php echo e($i+1); ?></th>
                                        <?php endfor; ?>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody class="table-bordered"><?php $no = 1;?>
                                    <?php for($i=0; $i < count($dominasi); $i++): ?>
                                    <tr>
                                        <?php $total = 0; ?>
                                        <td class="text-center"><b>Obat <?php echo e($no); ?></b></td>
                                        <?php for($j=0; $j < count($dominasi); $j++): ?>
                                        <td class="text-center">
                                        <?php if($i == $j): ?>
                                        &mdash;
                                        <?php else: ?>
                                        <?php echo e($dominasi[$i][$j]); ?>

                                        <?php
                                        $total = $total + $dominasi[$i][$j];
                                        ?>
                                        <?php endif; ?>
                                        </td>
                                        <?php endfor; ?>
                                        <td class="text-center"><b><?php echo e($total); ?></b></td>
                                    </tr>
                                    <?php $no++; ?>
                                    <?php endfor; ?>
                                </tbody>
                            </table>
                        </div><br>
                    </div>
                    <!--END RINCIAN-->
                </div>
                <!--END Tab Panes-->
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<!-- /.container-fluid -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function () {
        $(
            '#tableHasil'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "paging":false,
            "searching":false,
            "bInfo": false,
            "order": [[0, 'desc']]
        });
    });
</script>
<script>
    $(document).ready(function () {
        $(
            '#nilaiAwal'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "scrollY": "450px",
            "paging":false,
            "searching":false,
            "bInfo": false,
            "order":false,
        });
    });
</script>
<script>
    $(document).ready(function () {
        $(
            '#matriksNormalisasi'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "scrollY": "450px",
            "paging":false,
            "searching":false,
            "bInfo": false,
            "order":false,
        });
    });
</script>
<script>
    $(document).ready(function () {
        $(
            '#bobotNormalisasi'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "scrollY": "450px",
            "paging":false,
            "searching":false,
            "bInfo": false,
            "order":false,
        });
    });
</script>
<script>
    $(document).ready(function () {
        $(
            '#cIndex'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "scrollY": "450px",
            "paging":false,
            "searching":false,
            "bInfo": false,
            "bSortable": false,
            "ordering":false,
            "fixedColumns":   {
                "leftColumns": 1,
            },
        });
    });
</script>
<script>
    $(document).ready(function () {
        $(
            '#dIndex'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "scrollY": "450px",
            "paging":false,
            "searching":false,
            "bInfo": false,
            "bSortable": false,
            "ordering":false,
            "fixedColumns":   {
                "leftColumns": 1,
            },
        });
    });
</script>
<script>
    $(document).ready(function () {
        $(
            '#cMatriks'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "scrollY": "450px",
            "paging":false,
            "searching":false,
            "bInfo": false,
            "bSortable": false,
            "ordering":false,
            "fixedColumns":   {
                "leftColumns": 1,
            },
        });
    });
</script>
<script>
    $(document).ready(function () {
        $(
            '#cThreshold'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "scrollY": "450px",
            "paging":false,
            "searching":false,
            "bInfo": false,
            "bSortable": false,
            "ordering":false,
            "fixedColumns":   {
                "leftColumns": 1,
            },
        });
    });
</script>
<script>
    $(document).ready(function () {
        $(
            '#dMatriks'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "scrollY": "450px",
            "paging":false,
            "searching":false,
            "bInfo": false,
            "bSortable": false,
            "ordering":false,
            "fixedColumns":   {
                "leftColumns": 1,
            },
        });
    });
</script>
<script>
    $(document).ready(function () {
        $(
            '#dThreshold'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "scrollY": "450px",
            "paging":false,
            "searching":false,
            "bInfo": false,
            "bSortable": false,
            "ordering":false,
            "fixedColumns":   {
                "leftColumns": 1,
            },
        });
    });
</script>
<script>
    $(document).ready(function () {
        $(
            '#dominasi'
        ).DataTable({
            "processing": true,
            "bProcessing": true,
            "language": {
                'loadingRecords': '&nbsp;',
                'processing': '<i class="fas fa-spinner"></i>'
            },
            "deferRender": true,
            "scrollX": true,
            "scrollY": "450px",
            "paging":false,
            "searching":false,
            "bInfo": false,
            "bSortable": false,
            "ordering":false,
            "fixedColumns":   {
                "leftColumns": 1,
                "rightColumns": 1,
            },
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($role == 'master' ? 'layout.master' : 'layout.dokter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Amul\resources\views/electre/index.blade.php ENDPATH**/ ?>