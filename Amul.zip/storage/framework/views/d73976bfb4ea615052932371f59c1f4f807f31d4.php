<?php $__env->startSection('title', __('Forbidden')); ?>
<?php $__env->startSection('code', '403'); ?>
<?php $__env->startSection('message', __($exception->getMessage() ?: 'Forbidden')); ?>


<?php
if(Session::get('role') == NULL)
    return redirect()->route('login')->send()->with('warning','Silakan Login dahulu');
?>
<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Amul\resources\views/errors/403.blade.php ENDPATH**/ ?>