@extends('layout.master')
@section('content')
@include('dashboard')
@endsection