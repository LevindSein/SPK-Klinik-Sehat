@extends('layout.admin')
@section('content')
@include('dashboard')
@endsection