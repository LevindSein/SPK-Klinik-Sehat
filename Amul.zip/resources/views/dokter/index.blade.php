@extends('layout.dokter')
@section('content')
@include('dashboard')
@endsection